<?php

namespace simply_static_pro;

interface Minifer {

	public function minify( $content );
}